package com.itnint.badgedataservicedemo;

public class BadgeRequest {
    public String AuthKey;
    public String ActivationCode;
    public String DeviceIdentifier;
    public String NdefPayload;
    public String QrCode; // not yet implemented
}

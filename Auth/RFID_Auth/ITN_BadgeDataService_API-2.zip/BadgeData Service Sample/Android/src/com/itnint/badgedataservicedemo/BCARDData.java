package com.itnint.badgedataservicedemo;

public class BCARDData {
    public String AccountID;
    public String EventID;
    public String Salutation;
    public String Firstname;
    public String Lastname;
    public String Middlename;
    public String Suffix;
    public String Title;
    public String Company;
    public String Division;
    public String Address1;
    public String Address2;
    public String Address3;
    public String City;
    public String State;
    public String Zip;
    public String Country;
    public String TelCountryCode;
    public String Phone1;
    public String Phone2;
    public String Fax;
    public String Email;
    public String URL;
    public String StoredUID;
}

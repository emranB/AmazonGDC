package com.itnint.badgedataservicedemo;

public class BadgeReply {
	public boolean Success;
	public String ErrorMessage;
	public BCARDData BadgeData;
}
